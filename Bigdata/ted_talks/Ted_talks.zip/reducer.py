#!/usr/bin/python
import sys

views = 0
likes = 0
percentage = 0
oldId = None


for line in sys.stdin:
    data_mapped = line.strip().split(",")
    if len(data_mapped) != 3:
        continue

    thisId, view, like = data_mapped

    if oldId and oldId != thisId:
        print (oldId, ",", views,",",likes,",",percentage)
        oldId = thisId
        views = 0
        likes = 0
        percentage = 0
        

    oldId = thisId
    views += float(view)
    likes+= float(like)
    percentage = (likes*100)/views

if oldId != None:
    print (oldId, ",", views,",",likes,",",percentage)
